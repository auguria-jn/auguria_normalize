#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de nettoyage des mots de passe corrompus
Exécutez depuis le shell Odoo : ./odoo-bin shell -d votre_base < cleanup_corrupted_passwords.py
"""

print("="*70)
print("NETTOYAGE DES MOTS DE PASSE CORROMPUS")
print("="*70)

# 1. Compter les entrées
entries = env['password.entry'].search([])
print(f"\nNombre total d'entrées: {len(entries)}")

# 2. Tester chaque entrée
corrupted = []
valid = []

for entry in entries:
    if entry.encrypted_password:
        try:
            # Tenter de déchiffrer
            _ = entry.password
            if entry.password:
                valid.append(entry.id)
                print(f"✅ ID {entry.id}: {entry.description} - OK")
            else:
                corrupted.append(entry.id)
                print(f"⚠️  ID {entry.id}: {entry.description} - VIDE")
        except Exception as e:
            corrupted.append(entry.id)
            print(f"❌ ID {entry.id}: {entry.description} - CORROMPU ({str(e)[:50]})")
    else:
        print(f"⚠️  ID {entry.id}: {entry.description} - PAS DE MOT DE PASSE")

print(f"\n📊 RÉSUMÉ:")
print(f"   Valides: {len(valid)}")
print(f"   Corrompus: {len(corrupted)}")

# 3. Proposer le nettoyage
if corrupted:
    print(f"\n❓ Voulez-vous supprimer les encrypted_password corrompus ?")
    print(f"   (Les entrées resteront, seul le mot de passe sera vidé)")
    print(f"\n   Pour nettoyer, exécutez:")
    print(f"   entries_to_clean = env['password.entry'].browse({corrupted})")
    print(f"   entries_to_clean.write({{'encrypted_password': False}})")
    print(f"   env.cr.commit()")

    # Nettoyage automatique
    print(f"\n🧹 Nettoyage automatique en cours...")
    try:
        entries_to_clean = env['password.entry'].browse(corrupted)
        entries_to_clean.write({'encrypted_password': False})
        env.cr.commit()
        print(f"✅ {len(corrupted)} mots de passe corrompus nettoyés")
    except Exception as e:
        print(f"❌ Erreur lors du nettoyage: {str(e)}")
else:
    print("\n✅ Aucun mot de passe corrompu trouvé!")

print("\n" + "="*70)
print("FIN DU NETTOYAGE")
print("="*70)
