# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError
import base64
from cryptography.fernet import Fernet
import logging
import os

_logger = logging.getLogger(__name__)


def get_cipher(env):
    key = None
    source = None

    key = os.environ.get('ODOO_PASSWORD_ENCRYPTION_KEY')
    if key:
        source = "variable d'environnement"

    if not key:
        for key_file_path in ['/etc/odoo/encryption_key',
                               os.path.expanduser('~/.odoo/encryption_key')]:
            if os.path.exists(key_file_path) and os.access(key_file_path, os.R_OK):
                try:
                    with open(key_file_path, 'r') as f:
                        key = f.read().strip()
                    source = f"fichier {key_file_path}"
                    break
                except Exception as e:
                    _logger.warning(f"Impossible de lire {key_file_path}: {e}")

    if not key:
        key = env['ir.config_parameter'].sudo().get_param('password_manager.encryption_key')
        if key:
            source = "base de données"

    if not key:
        key = Fernet.generate_key().decode()
        env['ir.config_parameter'].sudo().set_param('password_manager.encryption_key', key)
        source = "nouvelle clé générée"
        _logger.warning("Nouvelle clé générée et sauvegardée en BDD.")

    try:
        return Fernet(key.encode())
    except Exception as e:
        _logger.error(f"Erreur cipher depuis {source}: {e}")
        new_key = Fernet.generate_key().decode()
        env['ir.config_parameter'].sudo().set_param('password_manager.encryption_key', new_key)
        return Fernet(new_key.encode())


class PasswordEntry(models.Model):
    _name = "password.entry"
    _description = "Entrée de mot de passe"
    _order = "description"
    _rec_name = "description"

    partner_id = fields.Many2one(
        "res.partner", string="Contact",
        required=True, ondelete="cascade", index=True,
    )
    description = fields.Char(
        string="Description", required=True, index=True,
        help="Ex: Compte Gmail, Accès FTP, etc.",
    )
    login    = fields.Char(string="Identifiant / Login")
    url      = fields.Char(string="URL du site")
    notes    = fields.Text(string="Notes")
    active   = fields.Boolean(string="Actif", default=True)

    encrypted_password = fields.Text(string="Mot de passe chiffré (base64)")
    password = fields.Char(
        string="Mot de passe",
        compute="_compute_password",
        inverse="_inverse_password",
        store=False,
        help="Automatiquement chiffré en base.",
    )

    # ── Partage par groupes ────────────────────────────────────────────────
    # Odoo 19 : res.users.group_ids (Many2many vers res.groups)
    shared_group_ids = fields.Many2many(
        "res.groups",
        "password_entry_group_rel",
        "entry_id",
        "group_id",
        string="Partagé avec les groupes",
        help="Groupes Odoo qui peuvent voir cette entrée en plus du propriétaire.",
    )
    sharing_summary = fields.Char(
        string="Visibilité",
        compute="_compute_sharing_summary",
        store=False,
    )

    # Métadonnées
    create_date = fields.Datetime(string="Date de création",     readonly=True)
    write_date  = fields.Datetime(string="Dernière modification", readonly=True)
    create_uid  = fields.Many2one('res.users', string="Créé par",    readonly=True)
    write_uid   = fields.Many2one('res.users', string="Modifié par", readonly=True)

    _sql_constraints = [
        ('unique_partner_description',
         'UNIQUE(partner_id, description)',
         'Une entrée avec cette description existe déjà pour ce contact !'),
    ]

    # ── Chiffrement ────────────────────────────────────────────────────────

    @api.depends('encrypted_password')
    def _compute_password(self):
        cipher = get_cipher(self.env)
        for rec in self:
            if rec.encrypted_password:
                try:
                    rec.password = cipher.decrypt(
                        base64.b64decode(rec.encrypted_password)
                    ).decode('utf-8')
                except Exception as e:
                    _logger.error(f"Déchiffrement impossible (id={rec.id}): {e}")
                    rec.password = ""
            else:
                rec.password = ""

    def _inverse_password(self):
        cipher = get_cipher(self.env)
        for rec in self:
            if rec.password:
                try:
                    rec.encrypted_password = base64.b64encode(
                        cipher.encrypt(rec.password.encode('utf-8'))
                    ).decode('ascii')
                except Exception as e:
                    raise ValidationError(f"Impossible de chiffrer le mot de passe: {e}")

    # ── Partage ────────────────────────────────────────────────────────────

    @api.depends('shared_group_ids')
    def _compute_sharing_summary(self):
        for rec in self:
            if rec.shared_group_ids:
                names = [n.split('/')[-1].strip()
                         for n in rec.shared_group_ids.mapped('name')]
                rec.sharing_summary = ', '.join(names)
            else:
                rec.sharing_summary = "Privé"

    # ── ORM ────────────────────────────────────────────────────────────────

    @api.model_create_multi
    def create(self, vals_list):
        cipher = get_cipher(self.env)
        for vals in vals_list:
            if vals.get('password'):
                try:
                    vals['encrypted_password'] = base64.b64encode(
                        cipher.encrypt(vals.pop('password').encode('utf-8'))
                    ).decode('ascii')
                except Exception as e:
                    raise ValidationError(f"Impossible de chiffrer le mot de passe: {e}")
        return super().create(vals_list)

    def write(self, vals):
        if 'password' in vals:
            pwd = vals.pop('password')
            if not pwd:
                vals['encrypted_password'] = False
            else:
                cipher = get_cipher(self.env)
                try:
                    vals['encrypted_password'] = base64.b64encode(
                        cipher.encrypt(pwd.encode('utf-8'))
                    ).decode('ascii')
                except Exception as e:
                    raise ValidationError(f"Impossible de chiffrer le mot de passe: {e}")
        return super().write(vals)

    def unlink(self):
        for rec in self:
            _logger.info(f"Suppression entrée: {rec.description} / {rec.partner_id.name}")
        return super().unlink()

    def copy(self, default=None):
        self.ensure_one()
        default = dict(default or {})
        default['description'] = f"{self.description} (copie)"
        default['encrypted_password'] = self.encrypted_password
        return super().copy(default)

    def _compute_display_name(self):
        for rec in self:
            name = f"{rec.partner_id.name} - {rec.description}"
            if rec.login:
                name += f" ({rec.login})"
            rec.display_name = name

    @api.model
    def _name_search(self, name='', domain=None, operator='ilike', limit=100, order=None):
        domain = list(domain or [])
        if name:
            domain = [
                '|', '|', '|',
                ('description', operator, name),
                ('login',       operator, name),
                ('url',         operator, name),
                ('partner_id.name', operator, name),
            ] + domain
        return self._search(domain, limit=limit, order=order)
