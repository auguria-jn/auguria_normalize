# -*- coding: utf-8 -*-
from odoo import models, fields, api

class ResPartner(models.Model):
    _inherit = "res.partner"

    password_entry_ids = fields.One2many(
        "password.entry",
        "partner_id",
        string="Mots de passe"
    )
    password_count = fields.Integer(
        string="Nombre de mots de passe",
        compute="_compute_password_count",
        store=True
    )

    @api.depends('password_entry_ids')
    def _compute_password_count(self):
        for partner in self:
            partner.password_count = len(partner.password_entry_ids)

    def action_view_passwords(self):
        """Ouvre la vue des mots de passe du contact."""
        self.ensure_one()
        return {
            'name': f'Mots de passe - {self.name}',
            'type': 'ir.actions.act_window',
            'res_model': 'password.entry',
            'view_mode': 'list,form',
            'domain': [('partner_id', '=', self.id)],
            'context': {
                'default_partner_id': self.id,
                'search_default_partner_id': self.id,
            }
        }
