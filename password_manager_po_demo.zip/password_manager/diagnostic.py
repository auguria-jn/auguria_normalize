#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de diagnostic pour le module password_manager
Exécutez depuis le shell Odoo : ./odoo-bin shell -d votre_base < diagnostic.py
"""

print("="*70)
print("DIAGNOSTIC MODULE PASSWORD MANAGER")
print("="*70)

# 1. Vérifier que le modèle existe
print("\n1. Vérification du modèle password.entry...")
try:
    model = env['password.entry']
    print("   ✅ Modèle password.entry trouvé")
except:
    print("   ❌ Modèle password.entry NON TROUVÉ")
    exit()

# 2. Vérifier les champs
print("\n2. Vérification des champs...")
fields = model._fields
required_fields = ['partner_id', 'description', 'login', 'url', 'encrypted_password', 'password', 'notes']
for field_name in required_fields:
    if field_name in fields:
        field = fields[field_name]
        print(f"   ✅ {field_name}: {field.__class__.__name__}")
    else:
        print(f"   ❌ {field_name}: MANQUANT")

# 3. Vérifier encrypted_password en détail
print("\n3. Détails du champ encrypted_password...")
if 'encrypted_password' in fields:
    field = fields['encrypted_password']
    print(f"   Type: {field.__class__.__name__}")
    print(f"   Store: {field.store}")
    print(f"   Column type: {field.column_type}")
else:
    print("   ❌ Champ encrypted_password manquant")

# 4. Vérifier le champ password (computed)
print("\n4. Détails du champ password...")
if 'password' in fields:
    field = fields['password']
    print(f"   Type: {field.__class__.__name__}")
    print(f"   Store: {field.store}")
    print(f"   Compute: {field.compute}")
    print(f"   Inverse: {field.inverse}")
else:
    print("   ❌ Champ password manquant")

# 5. Vérifier la clé de chiffrement
print("\n5. Vérification de la clé de chiffrement...")
key = env['ir.config_parameter'].sudo().get_param('password_manager.encryption_key')
if key:
    print(f"   ✅ Clé trouvée (longueur: {len(key)})")
else:
    print("   ❌ Clé de chiffrement NON TROUVÉE")

# 6. Test de création
print("\n6. Test de création d'une entrée...")
try:
    # Trouver un partenaire
    partner = env['res.partner'].search([('is_company', '=', True)], limit=1)
    if not partner:
        partner = env['res.partner'].search([], limit=1)

    print(f"   Partenaire: {partner.name}")

    # Créer une entrée de test
    vals = {
        'partner_id': partner.id,
        'description': 'TEST DIAGNOSTIC',
        'login': 'test@diagnostic.com',
        'password': 'TestPassword123!',
    }

    print(f"   Valeurs à créer: {vals}")

    entry = env['password.entry'].create(vals)
    print(f"   ✅ Entrée créée: ID={entry.id}")

    # Vérifier le chiffrement
    print(f"   encrypted_password présent: {bool(entry.encrypted_password)}")
    if entry.encrypted_password:
        print(f"   Longueur encrypted_password: {len(entry.encrypted_password)}")

    # Vérifier le déchiffrement
    print(f"   password (déchiffré): {entry.password}")

    # Sauvegarder
    env.cr.commit()
    print("   ✅ Commit effectué")

    # Relire depuis la base
    entry_reload = env['password.entry'].browse(entry.id)
    print(f"   password après reload: {entry_reload.password}")

    # Nettoyer
    entry.unlink()
    env.cr.commit()
    print("   ✅ Entrée de test supprimée")

except Exception as e:
    print(f"   ❌ ERREUR: {str(e)}")
    import traceback
    traceback.print_exc()

# 7. Vérifier les entrées existantes
print("\n7. Vérification des entrées existantes...")
try:
    entries = env['password.entry'].search([])
    print(f"   Nombre d'entrées: {len(entries)}")

    if entries:
        for entry in entries[:3]:  # Afficher max 3
            has_encrypted = bool(entry.encrypted_password)
            has_password = bool(entry.password)
            print(f"   - ID {entry.id}: {entry.description}")
            print(f"     encrypted_password: {has_encrypted}")
            print(f"     password (déchiffré): {'***' if has_password else 'VIDE'}")
except Exception as e:
    print(f"   ❌ ERREUR: {str(e)}")

print("\n" + "="*70)
print("FIN DU DIAGNOSTIC")
print("="*70)
