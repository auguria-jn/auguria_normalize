-- Script de correction de la base de données
-- Exécutez ce script si la colonne encrypted_password n'existe pas

-- Vérifier si la table existe
SELECT EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_name = 'password_entry'
);

-- Vérifier si la colonne existe
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'password_entry';

-- Ajouter la colonne si elle n'existe pas
DO $ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'password_entry' 
        AND column_name = 'encrypted_password'
    ) THEN
        ALTER TABLE password_entry ADD COLUMN encrypted_password bytea;
        RAISE NOTICE 'Colonne encrypted_password ajoutée avec succès';
    ELSE
        RAISE NOTICE 'Colonne encrypted_password existe déjà';
    END IF;
END $;

-- Vérification finale
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'password_entry' 
ORDER BY ordinal_position;
