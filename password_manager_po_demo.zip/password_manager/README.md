# Gestionnaire de Mots de Passe pour Odoo 18

Module de gestion sécurisée et chiffrée des mots de passe pour Odoo 18 Community Edition.

## 🔐 Fonctionnalités

- **Chiffrement AES** automatique de tous les mots de passe
- **Widget personnalisé** avec affichage/masquage et copie rapide
- **Générateur de mots de passe** aléatoires sécurisés
- **Gestion des droits** (Utilisateur/Manager)
- **Association aux contacts** avec compteur
- **Interface intuitive** dans les fiches contacts
- **Recherche avancée** et filtres
- **Historique** et traçabilité complète

## 📋 Prérequis

- Odoo 18 Community
- Python 3.8+
- Module `cryptography` : `pip install cryptography`

## 🚀 Installation

1. Installez la dépendance Python :
   ```bash
   pip install cryptography
   ```

2. Copiez le dossier `password_manager` dans votre répertoire addons Odoo

3. Redémarrez le serveur Odoo :
   ```bash
   sudo systemctl restart odoo
   # ou
   ./odoo-bin restart
   ```

4. Connectez-vous à Odoo et activez le mode développeur

5. Allez dans **Apps** → **Mise à jour de la liste des applications**

6. Recherchez "Gestionnaire de Mots de Passe" et installez-le

## 🔒 Sécurité

- Chiffrement Fernet (AES 128 bits en mode CBC)
- Clé de chiffrement générée automatiquement au premier lancement
- Stockage de la clé dans `ir.config_parameter`
- **IMPORTANT** : Sauvegardez la clé de chiffrement pour éviter toute perte de données

### Récupérer la clé de chiffrement

Menu **Paramètres** → **Technique** → **Paramètres système**
Recherchez : `password_manager.encryption_key`

## 👥 Gestion des droits

Deux niveaux d'accès disponibles :

- **Utilisateur** : Voit uniquement ses propres mots de passe
- **Manager** : Voit tous les mots de passe de la base

## 📚 Utilisation

### Depuis un contact

1. Ouvrez une fiche contact
2. Cliquez sur le bouton **"Mots de passe"** (en haut)
3. Ou allez dans l'onglet **"Sécurité"**
4. Ajoutez, modifiez ou supprimez des mots de passe

### Depuis le menu principal

- **Mots de passe** → **Tous les mots de passe**
- **Mots de passe** → **Mes mots de passe**

### Widget personnalisé

Le widget `password_copy` offre 3 fonctionnalités :
- 👁️ Afficher/Masquer le mot de passe
- 📋 Copier dans le presse-papier
- 🔄 Générer un mot de passe aléatoire (16 caractères)

## 🛠️ Configuration

Aucune configuration requise. Le module fonctionne immédiatement après installation.

## 📝 Licence

LGPL-3

## 🤝 Support

Pour toute question ou problème, contactez votre équipe de développement.
