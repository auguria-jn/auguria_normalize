# -*- coding: utf-8 -*-
"""
Migration 18.0 -> 19.0
Aucune modification de schéma requise.
Les données existantes (encrypted_password) restent compatibles.
"""
import logging

_logger = logging.getLogger(__name__)


def migrate(cr, version):
    if not version:
        return
    _logger.info(
        "password_manager: migration %s -> 19.0.1.0.0 — "
        "aucun changement de schéma, données compatibles.",
        version,
    )
