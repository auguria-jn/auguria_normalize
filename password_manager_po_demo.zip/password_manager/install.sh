#!/bin/bash
# Script d'installation rapide du module password_manager

echo "🔐 Installation du module Password Manager"
echo "=========================================="

# Vérifier si cryptography est installé
echo "📦 Vérification de la dépendance cryptography..."
if python3 -c "import cryptography" 2>/dev/null; then
    echo "✅ cryptography est déjà installé"
else
    echo "⚠️  Installation de cryptography..."
    pip3 install cryptography
    if [ $? -eq 0 ]; then
        echo "✅ cryptography installé avec succès"
    else
        echo "❌ Erreur lors de l'installation de cryptography"
        exit 1
    fi
fi

# Créer une icône simple si elle n'existe pas
if [ ! -f "static/description/icon.png" ]; then
    echo "⚠️  Création d'une icône par défaut..."
    # Créer une icône simple avec ImageMagick si disponible
    if command -v convert &> /dev/null; then
        convert -size 256x256 xc:#875a7b -gravity center -pointsize 120 -fill white -font DejaVu-Sans -annotate +0+0 "🔐" static/description/icon.png 2>/dev/null ||         convert -size 256x256 xc:#875a7b -gravity center -pointsize 80 -fill white -annotate +0+0 "KEY" static/description/icon.png
        echo "✅ Icône créée"
    else
        echo "⚠️  ImageMagick non installé. Veuillez créer icon.png manuellement"
        echo "   Ou installez ImageMagick : sudo apt-get install imagemagick"
    fi
fi

echo ""
echo "✅ Installation terminée!"
echo ""
echo "📋 Prochaines étapes :"
echo "1. Copiez ce dossier dans votre répertoire addons Odoo"
echo "   cp -r $(pwd) /chemin/vers/odoo/addons/"
echo "2. Redémarrez Odoo"
echo "   sudo systemctl restart odoo"
echo "3. Installez le module depuis l'interface Odoo"
echo "   Apps → Update Apps List → Recherchez 'Password' → Install"
echo ""
