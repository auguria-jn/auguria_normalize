{
    'name': 'Gestionnaire de Mots de Passe',
    'version': '19.0.1.0.0',
    'category': 'Tools',
    'summary': 'Gestion sécurisée et chiffrée des mots de passe',
    'description': """
        Gestionnaire de Mots de Passe
        ==============================

        Ce module permet de :
        * Stocker des mots de passe de manière sécurisée et chiffrée
        * Associer des mots de passe à des contacts
        * Afficher/masquer les mots de passe
        * Copier les mots de passe dans le presse-papier
        * Gérer plusieurs identifiants par contact

        Sécurité :
        * Chiffrement AES via cryptography (Fernet)
        * Clé de chiffrement stockée en base de données
        * Mots de passe jamais stockés en clair
    """,
    'author': 'Votre Entreprise',
    'website': 'https://www.votresite.com',
    'depends': ['base', 'contacts'],
    'external_dependencies': {
        'python': ['cryptography'],
    },
    'data': [
        'security/password_manager_security.xml',
        'security/ir.model.access.csv',
        'views/password_entry_views.xml',
        'views/res_partner_views.xml',
        'data/password_manager_data.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'password_manager/static/src/js/password_widget.js',
            'password_manager/static/src/xml/password_widget.xml',
        ],
    },
    'images': ['static/description/icon.png'],
    'license': 'LGPL-3',
    'installable': True,
    'application': True,
    'auto_install': False,
}
