/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component, useState } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";
import { standardFieldProps } from "@web/views/fields/standard_field_props";

/**
 * Widget personnalisé pour les champs mot de passe.
 * Compatible Odoo 19 / OWL 3.
 * Fonctionnalités : afficher/masquer, copier dans le presse-papier, générer.
 */
class PasswordCopyWidget extends Component {
    static template = "password_manager.PasswordFieldWidget";
    static props = {
        ...standardFieldProps,
    };

    setup() {
        this.notification = useService("notification");
        this.state = useState({
            visible: false,
        });
    }

    get value() {
        return this.props.record.data[this.props.name] || "";
    }

    get displayValue() {
        if (!this.value) return "";
        return this.state.visible ? this.value : "••••••••";
    }

    get isReadonly() {
        return this.props.readonly;
    }

    toggleVisibility() {
        this.state.visible = !this.state.visible;
    }

    async copyToClipboard() {
        if (!this.value) {
            this.notification.add("Aucun mot de passe à copier", { type: "warning" });
            return;
        }
        try {
            await navigator.clipboard.writeText(this.value);
            this.notification.add("Mot de passe copié !", { type: "success" });
            // Masquer automatiquement après 2 secondes
            setTimeout(() => {
                this.state.visible = false;
            }, 2000);
        } catch {
            this.notification.add("Erreur lors de la copie", { type: "danger" });
        }
    }

    generatePassword() {
        const length = 16;
        const charset =
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=";
        // Utilisation de crypto.getRandomValues pour plus de sécurité
        const array = new Uint32Array(length);
        crypto.getRandomValues(array);
        const password = Array.from(array, (n) => charset[n % charset.length]).join("");

        this.props.record.update({ [this.props.name]: password });
        this.state.visible = true;
        this.notification.add("Mot de passe généré", { type: "info" });
    }

    onChange(ev) {
        this.props.record.update({ [this.props.name]: ev.target.value });
    }
}

registry.category("fields").add("password_copy", {
    component: PasswordCopyWidget,
    supportedTypes: ["char"],
});
