ICÔNE DU MODULE
================

Vous devez créer un fichier icon.png dans ce dossier.

Spécifications :
- Format : PNG
- Taille recommandée : 256x256 pixels
- Nom du fichier : icon.png

Suggestions :
- Utilisez une icône de cadenas, clé ou bouclier
- Couleurs suggérées : #875a7b (violet Odoo) ou #21b799 (vert Odoo)

Vous pouvez :
1. Créer votre propre icône
2. Télécharger une icône gratuite depuis :
   - https://fontawesome.com/icons
   - https://www.flaticon.com/
   - https://iconarchive.com/

Exemple de commande pour créer une icône simple (Linux avec ImageMagick) :
convert -size 256x256 xc:#875a7b -gravity center -pointsize 120 -fill white -annotate +0+0 '🔐' icon.png

OU créez une icône simple avec le script install.sh fourni.
