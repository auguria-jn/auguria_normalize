# -*- coding: utf-8 -*-
# =============================================================================
# Module      : password_manager
# Fichier     : models/res_partner.py
# Description : Extension du modèle res.partner pour y associer des entrées
#               de mots de passe et afficher leur compteur dans le formulaire.
# Auteur      : AUDURIA by ANOR
# Création    : 2026-03-04
# Mise à jour : 2026-03-04
# =============================================================================

from odoo import models, fields, api


class ResPartner(models.Model):
    """
    Modèle : res.partner (héritage)
    Rôle fonctionnel : Ajoute la relation One2many vers password.entry et
    un compteur calculé affiché sous forme de stat button dans le formulaire
    contact standard d'Odoo.
    """

    _inherit = "res.partner"

    # -------------------------------------------------------------------------
    # Champs
    # -------------------------------------------------------------------------

    password_entry_ids = fields.One2many(
        "password.entry",
        "partner_id",
        string="Mots de passe",
    )
    # Nombre d'entrées actives — stocké pour éviter un recalcul à chaque lecture
    password_count = fields.Integer(
        string="Nombre de mots de passe",
        compute="_compute_password_count",
        store=True,
    )

    # -------------------------------------------------------------------------
    # Méthodes de calcul
    # -------------------------------------------------------------------------

    @api.depends('password_entry_ids')
    def _compute_password_count(self):
        """
        Compte les entrées de mots de passe liées au contact.
        Utilisé pour l'affichage du stat button dans le formulaire contact.
        """
        for partner in self:
            partner.password_count = len(partner.password_entry_ids)

    # -------------------------------------------------------------------------
    # Actions métier
    # -------------------------------------------------------------------------

    def action_view_passwords(self):
        """
        Ouvre la liste des entrées de mots de passe filtrée sur ce contact.
        Appelée depuis le stat button "Mots de passe" du formulaire contact.
        """
        self.ensure_one()
        return {
            'name': 'Mots de passe - %s' % self.name,
            'type': 'ir.actions.act_window',
            'res_model': 'password.entry',
            'view_mode': 'list,form',
            'domain': [('partner_id', '=', self.id)],
            'context': {
                'default_partner_id': self.id,
                'search_default_partner_id': self.id,
            },
        }
