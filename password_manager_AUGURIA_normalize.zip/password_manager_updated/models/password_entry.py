# -*- coding: utf-8 -*-
# =============================================================================
# Module      : password_manager
# Fichier     : models/password_entry.py
# Description : Modèle principal de gestion des entrées de mot de passe.
#               Gère le chiffrement/déchiffrement AES (Fernet), le partage par
#               groupes Odoo et les règles de recherche avancées.
# Auteur      : AUDURIA by ANOR
# Création    : 2026-03-04
# Mise à jour : 2026-03-04
# =============================================================================

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import base64
from cryptography.fernet import Fernet
from cryptography.exceptions import InvalidToken
import logging
import os

_logger = logging.getLogger(__name__)


def get_cipher(env):
    """
    Charge ou génère la clé de chiffrement Fernet.

    Ordre de priorité :
    1. Variable d'environnement ODOO_PASSWORD_ENCRYPTION_KEY
    2. Fichier /etc/odoo/encryption_key ou ~/.odoo/encryption_key
    3. Paramètre système password_manager.encryption_key (base de données)
    4. Génération d'une nouvelle clé sauvegardée en base (fallback)

    Note sécurité : l'accès aux paramètres système (ir.config_parameter) requiert
    sudo() car les utilisateurs standards n'ont pas de droit de lecture/écriture
    sur ce modèle. Ce sudo() est limité à la gestion de la clé de chiffrement
    et ne s'applique à aucune autre donnée. La clé en base de données doit être
    considérée comme un fallback de dernier recours ; en production, préférer
    la variable d'environnement ou un fichier sécurisé.

    Retourne une instance Fernet prête à l'emploi.
    """
    key = None
    source = None

    # Priorité 1 : variable d'environnement (recommandé en production)
    key = os.environ.get('ODOO_PASSWORD_ENCRYPTION_KEY')
    if key:
        source = "variable d'environnement"

    # Priorité 2 : fichier système ou fichier utilisateur
    if not key:
        for key_file_path in ['/etc/odoo/encryption_key',
                               os.path.expanduser('~/.odoo/encryption_key')]:
            if os.path.exists(key_file_path) and os.access(key_file_path, os.R_OK):
                try:
                    with open(key_file_path, 'r') as f:
                        key = f.read().strip()
                    source = "fichier %s" % key_file_path
                    break
                except Exception as e:
                    _logger.warning("Impossible de lire %s : %s", key_file_path, e)

    # Priorité 3 : paramètre système Odoo
    # sudo() justifié : ir.config_parameter n'est pas accessible aux utilisateurs
    # standards. La portée est strictement limitée à la lecture/écriture de la clé.
    if not key:
        key = env['ir.config_parameter'].sudo().get_param('password_manager.encryption_key')
        if key:
            source = "base de données (ir.config_parameter)"

    # Priorité 4 : génération d'une nouvelle clé (fallback — à éviter en production)
    if not key:
        key = Fernet.generate_key().decode()
        # sudo() justifié : même raison que ci-dessus, écriture de la clé générée
        env['ir.config_parameter'].sudo().set_param('password_manager.encryption_key', key)
        source = "nouvelle clé générée"
        _logger.warning(
            "Nouvelle clé de chiffrement générée et sauvegardée en base de données. "
            "Pour une meilleure sécurité, définissez ODOO_PASSWORD_ENCRYPTION_KEY "
            "ou utilisez un fichier dédié."
        )

    try:
        return Fernet(key.encode())
    except Exception as e:
        _logger.error("Erreur lors de la construction du cipher depuis %s : %s", source, e)
        new_key = Fernet.generate_key().decode()
        env['ir.config_parameter'].sudo().set_param('password_manager.encryption_key', new_key)
        return Fernet(new_key.encode())


class PasswordEntry(models.Model):
    """
    Modèle : password.entry
    Rôle fonctionnel : Stocke de manière sécurisée les identifiants et mots
    de passe associés aux contacts Odoo. Le mot de passe est chiffré en AES
    (Fernet) avant toute persistance en base de données.
    """

    _name = "password.entry"
    _description = "Entrée de mot de passe"
    _order = "description"
    _rec_name = "description"

    # -------------------------------------------------------------------------
    # Champs
    # -------------------------------------------------------------------------

    partner_id = fields.Many2one(
        "res.partner", string="Contact",
        required=True, ondelete="cascade", index=True,
    )
    description = fields.Char(
        string="Description", required=True, index=True,
        help="Ex: Compte Gmail, Accès FTP, etc.",
    )
    login = fields.Char(string="Identifiant / Login")
    url = fields.Char(string="URL du site")
    notes = fields.Text(string="Notes")
    active = fields.Boolean(string="Actif", default=True)

    # Mot de passe chiffré persisté en base (jamais le clair)
    encrypted_password = fields.Text(string="Mot de passe chiffré (base64)")

    # Champ virtuel : déchiffré à la lecture, rechiffré à l'écriture
    password = fields.Char(
        string="Mot de passe",
        compute="_compute_password",
        inverse="_inverse_password",
        store=False,
        help="Automatiquement chiffré lors de la sauvegarde en base.",
    )

    # Partage par groupes Odoo (Many2many vers res.groups)
    shared_group_ids = fields.Many2many(
        "res.groups",
        "password_entry_group_rel",
        "entry_id",
        "group_id",
        string="Partagé avec les groupes",
        help="Groupes Odoo qui peuvent voir cette entrée en plus du propriétaire.",
    )
    # Résumé lisible de la visibilité (calculé, non stocké — voir note D03 dans controle_qualite.md)
    sharing_summary = fields.Char(
        string="Visibilité",
        compute="_compute_sharing_summary",
        store=False,
    )

    # Métadonnées automatiques (readonly)
    create_date = fields.Datetime(string="Date de création", readonly=True)
    write_date = fields.Datetime(string="Dernière modification", readonly=True)
    create_uid = fields.Many2one('res.users', string="Créé par", readonly=True)
    write_uid = fields.Many2one('res.users', string="Modifié par", readonly=True)

    # -------------------------------------------------------------------------
    # Contraintes
    # -------------------------------------------------------------------------

    _sql_constraints = [
        ('unique_partner_description',
         'UNIQUE(partner_id, description)',
         'Une entrée avec cette description existe déjà pour ce contact !'),
    ]

    # -------------------------------------------------------------------------
    # Méthodes de calcul
    # -------------------------------------------------------------------------

    @api.depends('encrypted_password')
    def _compute_password(self):
        """
        Déchiffre le mot de passe stocké en base pour chaque entrée.
        Seules les erreurs de déchiffrement Fernet (InvalidToken) et de
        valeur (ValueError) sont interceptées, afin de ne pas masquer
        les erreurs de programmation inattendues.
        """
        cipher = get_cipher(self.env)
        for rec in self:
            if rec.encrypted_password:
                try:
                    rec.password = cipher.decrypt(
                        base64.b64decode(rec.encrypted_password)
                    ).decode('utf-8')
                except (InvalidToken, ValueError) as e:
                    _logger.error(
                        "Déchiffrement impossible pour l'entrée id=%s "
                        "(clé incorrecte ou données corrompues) : %s", rec.id, e
                    )
                    rec.password = ""
            else:
                rec.password = ""

    def _inverse_password(self):
        """
        Chiffre le mot de passe saisi avant sa persistance en base.
        Appelé automatiquement lors d'une écriture sur le champ `password`.
        """
        cipher = get_cipher(self.env)
        for rec in self:
            if rec.password:
                try:
                    rec.encrypted_password = base64.b64encode(
                        cipher.encrypt(rec.password.encode('utf-8'))
                    ).decode('ascii')
                except (ValueError, TypeError) as e:
                    raise ValidationError(
                        _("Impossible de chiffrer le mot de passe : %s") % e
                    )

    @api.depends('shared_group_ids')
    def _compute_sharing_summary(self):
        """
        Calcule le libellé de visibilité à partir des groupes de partage.
        Retourne "Privé" si aucun groupe n'est sélectionné.
        """
        for rec in self:
            if rec.shared_group_ids:
                names = [n.split('/')[-1].strip()
                         for n in rec.shared_group_ids.mapped('name')]
                rec.sharing_summary = ', '.join(names)
            else:
                rec.sharing_summary = _("Privé")

    # -------------------------------------------------------------------------
    # CRUD
    # -------------------------------------------------------------------------

    @api.model_create_multi
    def create(self, vals_list):
        """
        Surcharge de la création : chiffre le mot de passe en clair avant
        l'écriture en base si la clé `password` est présente dans les valeurs.
        """
        cipher = get_cipher(self.env)
        for vals in vals_list:
            if vals.get('password'):
                try:
                    vals['encrypted_password'] = base64.b64encode(
                        cipher.encrypt(vals.pop('password').encode('utf-8'))
                    ).decode('ascii')
                except (ValueError, TypeError) as e:
                    raise ValidationError(
                        _("Impossible de chiffrer le mot de passe : %s") % e
                    )
        return super().create(vals_list)

    def write(self, vals):
        """
        Surcharge de l'écriture : intercepte la clé `password` pour chiffrer
        avant la persistance. Supprime encrypted_password si password est vide.
        """
        if 'password' in vals:
            pwd = vals.pop('password')
            if not pwd:
                vals['encrypted_password'] = False
            else:
                cipher = get_cipher(self.env)
                try:
                    vals['encrypted_password'] = base64.b64encode(
                        cipher.encrypt(pwd.encode('utf-8'))
                    ).decode('ascii')
                except (ValueError, TypeError) as e:
                    raise ValidationError(
                        _("Impossible de chiffrer le mot de passe : %s") % e
                    )
        return super().write(vals)

    def unlink(self):
        """
        Surcharge de la suppression : journalise les entrées supprimées
        pour faciliter les audits de sécurité.
        """
        for rec in self:
            _logger.info(
                "Suppression entrée mot de passe : %s / %s",
                rec.description, rec.partner_id.name
            )
        return super().unlink()

    def copy(self, default=None):
        """
        Duplication d'une entrée : suffixe automatiquement la description
        et conserve le mot de passe chiffré d'origine.
        """
        self.ensure_one()
        default = dict(default or {})
        default['description'] = _("%s (copie)") % self.description
        default['encrypted_password'] = self.encrypted_password
        return super().copy(default)

    # -------------------------------------------------------------------------
    # Actions métier
    # -------------------------------------------------------------------------

    def _compute_display_name(self):
        """
        Construit le nom d'affichage sous la forme :
        "Nom Contact - Description (login)"
        """
        for rec in self:
            name = "%s - %s" % (rec.partner_id.name, rec.description)
            if rec.login:
                name += " (%s)" % rec.login
            rec.display_name = name

    @api.model
    def _name_search(self, name='', domain=None, operator='ilike', limit=100, order=None):
        """
        Recherche étendue sur la description, le login, l'URL et le contact.
        Permet de retrouver une entrée en tapant n'importe quel champ visible.
        """
        domain = list(domain or [])
        if name:
            domain = [
                '|', '|', '|',
                ('description', operator, name),
                ('login', operator, name),
                ('url', operator, name),
                ('partner_id.name', operator, name),
            ] + domain
        return self._search(domain, limit=limit, order=order)
