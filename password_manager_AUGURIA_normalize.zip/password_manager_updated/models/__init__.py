# -*- coding: utf-8 -*-
from . import password_entry
from . import res_partner
