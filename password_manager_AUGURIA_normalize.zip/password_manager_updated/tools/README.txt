Dossier tools/ — Scripts utilitaires de maintenance
====================================================

Ce dossier contient des scripts d'aide au déploiement et à la maintenance.
Ces fichiers ne font PAS partie du module Odoo et ne sont pas référencés dans
le __manifest__.py. Ils ne doivent PAS être inclus dans un package de production
déposé sur l'Odoo Apps Store.

Contenu :
- diagnostic.py            : Outil de diagnostic de l'état du chiffrement
- cleanup_corrupted_passwords.py : Nettoyage des entrées dont le déchiffrement échoue
- fix_database.sql         : Requêtes SQL de maintenance directe en base
- install.sh               : Script d'installation de la dépendance Python (cryptography)

Usage : exécuter ces scripts manuellement depuis le serveur, en dehors d'Odoo.
