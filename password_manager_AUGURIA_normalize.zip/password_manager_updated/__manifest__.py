{
    'name': 'Gestionnaire de Mots de Passe',
    'version': '19.0.1.0.0',
    'category': 'Tools',
    'summary': 'Gestion sécurisée et chiffrée des mots de passe',
    'description': """
        Gestionnaire de Mots de Passe
        ==============================

        Ce module permet de :
        * Stocker des mots de passe de manière sécurisée et chiffrée (AES/Fernet)
        * Associer des mots de passe à des contacts Odoo
        * Afficher/masquer et copier les mots de passe depuis l'interface
        * Générer des mots de passe aléatoires sécurisés
        * Partager des entrées avec des groupes Odoo spécifiques

        Sécurité :
        * Chiffrement AES via la bibliothèque cryptography (Fernet)
        * Clé de chiffrement chargeable depuis variable d'environnement ou fichier
        * Les mots de passe ne sont jamais stockés en clair en base de données
    """,
    'author': 'AUDURIA by ANOR',
    'website': 'https://auduria.fr',
    'license': 'LGPL-3',
    'depends': ['base', 'contacts'],
    'external_dependencies': {
        'python': ['cryptography'],
    },
    'data': [
        'security/password_manager_security.xml',
        'security/ir.model.access.csv',
        'views/password_entry_views.xml',
        'views/res_partner_views.xml',
        'data/password_manager_data.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'password_manager/static/src/js/password_widget.js',
            'password_manager/static/src/xml/password_widget.xml',
        ],
    },
    'images': ['static/description/icon.png'],
    'installable': True,
    'application': True,
    'auto_install': False,
}
