/** @odoo-module **/
// =============================================================================
// Module      : password_manager
// Fichier     : static/src/js/password_widget.js
// Description : Widget OWL personnalisé pour les champs mot de passe.
//               Fonctionnalités : afficher/masquer, copier dans le presse-papier,
//               générer un mot de passe sécurisé. Compatible Odoo 19 / OWL 3.
// Auteur      : AUDURIA by ANOR
// Création    : 2026-03-04
// Mise à jour : 2026-03-04
// =============================================================================

import { registry } from "@web/core/registry";
import { Component, useState } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";
import { standardFieldProps } from "@web/views/fields/standard_field_props";

class PasswordCopyWidget extends Component {
    static template = "password_manager.PasswordFieldWidget";
    static props = {
        ...standardFieldProps,
    };

    setup() {
        this.notification = useService("notification");
        this.state = useState({
            visible: false,
        });
    }

    /** Valeur brute du champ depuis le record courant */
    get value() {
        return this.props.record.data[this.props.name] || "";
    }

    /** Affiche des bullets ou le mot de passe en clair selon l'état de visibilité */
    get displayValue() {
        if (!this.value) return "";
        return this.state.visible ? this.value : "••••••••";
    }

    get isReadonly() {
        return this.props.readonly;
    }

    /** Bascule l'affichage en clair / masqué */
    toggleVisibility() {
        this.state.visible = !this.state.visible;
    }

    /** Copie le mot de passe dans le presse-papier et masque automatiquement après 2 s */
    async copyToClipboard() {
        if (!this.value) {
            this.notification.add("Aucun mot de passe à copier", { type: "warning" });
            return;
        }
        try {
            await navigator.clipboard.writeText(this.value);
            this.notification.add("Mot de passe copié !", { type: "success" });
            setTimeout(() => {
                this.state.visible = false;
            }, 2000);
        } catch {
            this.notification.add("Erreur lors de la copie", { type: "danger" });
        }
    }

    /**
     * Génère un mot de passe aléatoire de 16 caractères via crypto.getRandomValues.
     * Utilise un charset alphanumérique + caractères spéciaux courants.
     */
    generatePassword() {
        const length = 16;
        const charset =
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=";
        const array = new Uint32Array(length);
        crypto.getRandomValues(array);
        const password = Array.from(array, (n) => charset[n % charset.length]).join("");

        this.props.record.update({ [this.props.name]: password });
        this.state.visible = true;
        this.notification.add("Mot de passe généré", { type: "info" });
    }

    onChange(ev) {
        this.props.record.update({ [this.props.name]: ev.target.value });
    }
}

registry.category("fields").add("password_copy", {
    component: PasswordCopyWidget,
    supportedTypes: ["char"],
});
