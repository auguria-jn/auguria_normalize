Gestionnaire de Mots de Passe
==============================

Description
-----------

Ce module Odoo permet de stocker et gérer de manière sécurisée les identifiants
et mots de passe associés aux contacts de votre base. Chaque mot de passe est
chiffré en AES (algorithme Fernet) avant persistance : aucun mot de passe n'est
jamais stocké en clair dans la base de données.

Fonctionnalités
---------------

* Stocker des entrées (service, login, URL, notes) liées à un contact Odoo
* Chiffrement AES automatique via la bibliothèque Python ``cryptography``
* Widget interactif : afficher/masquer, copier en un clic, générer un mot de passe
* Partage d'entrées avec des groupes Odoo spécifiques
* Règles d'accès par enregistrement : chaque utilisateur ne voit que ses propres
  entrées et celles qui lui ont été explicitement partagées
* Accès complet pour les managers
* Intégration dans le formulaire contact (stat button + onglet Sécurité)

Installation
------------

Ce module requiert la bibliothèque Python ``cryptography`` :

.. code-block:: bash

   pip install cryptography

Dépendances Odoo : ``base``, ``contacts``

Configuration
-------------

La clé de chiffrement est chargée selon cet ordre de priorité :

1. Variable d'environnement ``ODOO_PASSWORD_ENCRYPTION_KEY``
2. Fichier ``/etc/odoo/encryption_key`` ou ``~/.odoo/encryption_key``
3. Paramètre système ``password_manager.encryption_key`` (base de données)
4. Génération automatique d'une nouvelle clé (sauvegardée en base, fallback)

**Recommandation** : utiliser la variable d'environnement ou un fichier sécurisé
pour une meilleure isolation de la clé.

Usage
-----

1. Ouvrir un contact Odoo
2. Cliquer sur le bouton **Mots de passe** (icône clé)
3. Ajouter une entrée : description, login, URL, mot de passe
4. Le mot de passe peut être généré automatiquement via le bouton ↻
5. Utiliser le menu **Mots de passe** pour une vue globale de toutes les entrées

Auteurs & Mainteneurs
---------------------

* **AUDURIA by ANOR** — https://auduria.fr
