# Contrôle Qualité — password_manager

> **Module** : Gestionnaire de Mots de Passe
> **Version** : 19.0.1.0.0
> **Date d'audit** : 2026-03-04
> **Auditeur** : Claude (AUGURIA by ANOR)
> **Mise à jour** : 2026-03-04 — Corrections appliquées suite au retour client

---

## Synthèse après corrections

| Niveau | Avant | Après |
|--------|-------|-------|
| 🔴 Critique | 0 | 0 |
| 🟠 Important | 3 | 0 ✅ |
| 🟡 Mineur | 4 | 0 ✅ |
| 🔵 Info | 2 | 1 (D03 store=False volontaire) |
| ✅ Conforme | 27 | 34 |

**Toutes les cases cochées ont été appliquées.** La case D03 (`store=True` sur `sharing_summary`) n'a pas été cochée : `sharing_summary` reste non stocké (décision conservée).

---

## Corrections appliquées

### ✅ A05 — Documentation du `sudo()` dans `get_cipher()`
- Commentaire détaillé ajouté expliquant pourquoi `sudo()` est nécessaire pour `ir.config_parameter`
- Mention explicite que la portée est strictement limitée à la clé de chiffrement
- Recommandation de production ajoutée dans le message de warning

### ✅ A07 — `except Exception` remplacé par `except (InvalidToken, ValueError)`
- Import `from cryptography.exceptions import InvalidToken` ajouté
- Tous les blocs `except Exception` de `_compute_password` et méthodes associées remplacés par des exceptions ciblées
- Message d'erreur enrichi pour faciliter le diagnostic (précise "clé incorrecte ou données corrompues")

### ✅ A12 — Chaînes enveloppées dans `_()`
- `from odoo import ..., _` ajouté
- `"Impossible de chiffrer le mot de passe"` → `_("Impossible de chiffrer le mot de passe : %s") % e`
- `"Privé"` → `_("Privé")`
- `"(copie)"` → `_("%s (copie)") % self.description`

### ✅ C03 — Décision d'accès Manager documentée
- Grand commentaire de conception ajouté dans `security/password_manager_security.xml` avant la règle Manager
- Explique le rationnel métier (supervision départs, gestion orphelins, audits)
- Avertissement explicite sur la sensibilité du profil Manager
- Indication de comment restreindre à l'avenir si besoin

### ✅ B — Action dédiée "Mes mots de passe"
- Nouvelle action `action_password_entry_my` créée avec `domain="[('create_uid', '=', uid)]"`
- Filtre de recherche `my_entries` ajouté dans la vue de recherche
- Menu `menu_password_my_entries` pointe désormais vers cette action dédiée

### ✅ E — Scripts utilitaires déplacés dans `tools/`
- `diagnostic.py`, `cleanup_corrupted_passwords.py`, `fix_database.sql`, `install.sh` déplacés dans `tools/`
- `tools/README.txt` créé pour expliquer le rôle de ce dossier et avertir qu'il ne fait pas partie du module Odoo
- Ces fichiers ne sont pas référencés dans `__manifest__.py`

### ✅ E — Dossier `migrations/` supprimé
- `migrations/19.0.1.0.0/pre-migrate.py` supprimé : aucune migration nécessaire lors de l'installation initiale d'un module

---

## Point non appliqué

### ⬜ D03 — `store=True` sur `sharing_summary` (non coché)
- `sharing_summary` reste `store=False` (décision conservée par le commanditaire)
- À réévaluer si des problèmes de performance apparaissent sur des listes > 100 entrées
- Note : une migration serait nécessaire pour activer le stockage sur un système existant

---

## État final — Tous les contrôles

| Contrôle | Statut | Note |
|----------|--------|------|
| A01 — Imports inutilisés | ✅ Conforme | |
| A02 — Champs non utilisés | ✅ Conforme | |
| A03 — Duplication de méthodes | ✅ Conforme | |
| A04 — Méthodes trop longues | ✅ Conforme | |
| A05 — sudo() justifié | ✅ Corrigé | Documenté |
| A06 — SQL brut | ✅ Conforme | |
| A07 — except trop large | ✅ Corrigé | InvalidToken + ValueError |
| A08 — search() en boucle | ✅ Conforme | |
| A09 — compute sans depends | ✅ Conforme | |
| A10 — onchange vs compute | ✅ Conforme | |
| A11 — héritage sans valeur | ✅ Conforme | |
| A12 — chaînes non traduites | ✅ Corrigé | _() appliqué |
| B01 — records en double | ✅ Conforme | |
| B02 — XPath fragiles | ✅ Conforme | |
| B03 — groupes non définis | ✅ Conforme | |
| B04 — actions vers modèles inexistants | ✅ Conforme | |
| B05 — champs absents du modèle | ✅ Conforme | |
| B06 — fichiers XML absents | ✅ Conforme | |
| B07 — XML non listés | ✅ Conforme | |
| B — Menu "Mes mots de passe" | ✅ Corrigé | Action dédiée avec domain |
| C01 — règles d'accès manquantes | ✅ Conforme | |
| C02 — TransientModel non restreint | ✅ Conforme | Aucun TransientModel |
| C03 — domain ouvert Manager | ✅ Corrigé | Décision documentée |
| C04 — hiérarchie groupes | ✅ Conforme | |
| D01 — search() en boucle | ✅ Conforme | |
| D02 — write() un par un | ✅ Conforme | |
| D03 — compute non stockés | 🔵 Info | Volontaire pour password ; conservé pour sharing_summary |
| D04 — compute + search | ✅ Conforme | |
| D05 — absence _order | ✅ Conforme | |
| E01 — logique dans contrôleur | ✅ Conforme | |
| E02 — wizard modifie données | ✅ Conforme | |
| E03 — démo mélangée prod | ✅ Conforme | |
| E04 — _name vs _table | ✅ Conforme | |
| E05 — absence _description | ✅ Conforme | |
| E06 — Selection en dur | ✅ Conforme | |
| E07 — absence _rec_name | ✅ Conforme | |
| E — fichiers utilitaires | ✅ Corrigé | Déplacés dans tools/ |
| E — dossier migrations v1 | ✅ Corrigé | Supprimé |
