# -*- coding: utf-8 -*-
# =============================================================================
# Module      : password_manager
# Fichier     : tests/test_security.py
# Description : Tests de sécurité — droits d'accès CRUD et record rules.
#               Couvre : ir.model.access.csv (Utilisateur, Manager),
#               record rule "propriétaire ou partagé", record rule "manager voit tout".
# Auteur      : AUDURIA by ANOR
# Création    : 2026-03-04
# Mise à jour : 2026-03-04
# =============================================================================

from odoo.exceptions import AccessError
from odoo.tests.common import tagged
from .common import PasswordManagerTestCommon


# =============================================================================
# Droits CRUD — groupe Utilisateur
# =============================================================================

@tagged('post_install', '-at_install')
class TestAccessRightsUser(PasswordManagerTestCommon):
    """
    Tests des droits d'accès CRUD pour le groupe group_password_user.
    Couvre : lecture, création, écriture, suppression (tous autorisés selon ir.model.access.csv).
    """

    def test_user_can_read_own_entry(self):
        """Vérifie qu'un utilisateur peut lire ses propres entrées."""
        # --- Act ---
        entries = self.env['password.entry'].with_user(
            self.user_employee
        ).search([('create_uid', '=', self.user_employee.id)])
        # --- Assert ---
        self.assertGreaterEqual(len(entries), 1)

    def test_user_can_create_entry(self):
        """Vérifie qu'un utilisateur du groupe peut créer une entrée."""
        # --- Act ---
        entry = self.env['password.entry'].with_user(self.user_employee).create({
            'partner_id': self.partner_alice.id,
            'description': 'Création par user',
            'password': 'createpass',
        })
        # --- Assert ---
        self.assertTrue(entry.exists())

    def test_user_can_write_own_entry(self):
        """Vérifie qu'un utilisateur peut modifier ses propres entrées."""
        # --- Arrange ---
        entry = self.env['password.entry'].with_user(self.user_employee).create({
            'partner_id': self.partner_alice.id,
            'description': 'Écriture par user',
        })
        # --- Act ---
        entry.with_user(self.user_employee).write({'login': 'nouveau_login'})
        # --- Assert ---
        self.assertEqual(entry.login, 'nouveau_login')

    def test_user_can_delete_own_entry(self):
        """Vérifie qu'un utilisateur peut supprimer ses propres entrées."""
        # --- Arrange ---
        entry = self.env['password.entry'].with_user(self.user_employee).create({
            'partner_id': self.partner_alice.id,
            'description': 'Suppression par user',
        })
        entry_id = entry.id
        # --- Act ---
        entry.with_user(self.user_employee).unlink()
        # --- Assert ---
        self.assertFalse(
            self.env['password.entry'].search([('id', '=', entry_id)]).exists()
        )

    def test_user_without_group_cannot_read(self):
        """Vérifie qu'un utilisateur sans le groupe password_user ne peut pas lire."""
        # --- Act / Assert ---
        with self.assertRaises(AccessError):
            self.env['password.entry'].with_user(self.user_other).search([])

    def test_user_without_group_cannot_create(self):
        """Vérifie qu'un utilisateur sans le groupe password_user ne peut pas créer."""
        # --- Act / Assert ---
        with self.assertRaises(AccessError):
            self.env['password.entry'].with_user(self.user_other).create({
                'partner_id': self.partner_alice.id,
                'description': 'Accès interdit',
            })


# =============================================================================
# Droits CRUD — groupe Manager
# =============================================================================

@tagged('post_install', '-at_install')
class TestAccessRightsManager(PasswordManagerTestCommon):
    """
    Tests des droits d'accès CRUD pour le groupe group_password_manager.
    Couvre : toutes les opérations, y compris sur les entrées d'autres utilisateurs.
    """

    def test_manager_can_read_all_entries(self):
        """Vérifie qu'un manager peut lire toutes les entrées (record rule ouverte)."""
        # --- Act ---
        entries = self.env['password.entry'].with_user(self.user_manager).search([])
        # --- Assert ---
        # Le manager doit voir au moins les deux entrées créées dans common.py
        self.assertGreaterEqual(len(entries), 2)

    def test_manager_can_read_entry_of_other_user(self):
        """Vérifie qu'un manager peut lire une entrée appartenant à un autre utilisateur."""
        # --- Act ---
        entry = self.env['password.entry'].with_user(self.user_manager).browse(
            self.entry_alice_main.id
        )
        # --- Assert ---
        self.assertTrue(entry.exists())
        self.assertEqual(entry.description, self.entry_alice_main.description)

    def test_manager_can_write_entry_of_other_user(self):
        """Vérifie qu'un manager peut modifier une entrée appartenant à un autre utilisateur."""
        # --- Act ---
        self.entry_alice_main.with_user(self.user_manager).write({
            'notes': 'Note ajoutée par le manager',
        })
        # --- Assert ---
        self.assertEqual(self.entry_alice_main.notes, 'Note ajoutée par le manager')

    def test_manager_can_delete_entry_of_other_user(self):
        """Vérifie qu'un manager peut supprimer une entrée appartenant à un autre utilisateur."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Entrée à supprimer par manager',
        })
        entry_id = entry.id
        # --- Act ---
        entry.with_user(self.user_manager).unlink()
        # --- Assert ---
        self.assertFalse(
            self.env['password.entry'].search([('id', '=', entry_id)]).exists()
        )


# =============================================================================
# Record rules
# =============================================================================

@tagged('post_install', '-at_install')
class TestRecordRuleUser(PasswordManagerTestCommon):
    """
    Tests de la record rule utilisateur :
    "Visible si create_uid = moi OU shared_group_ids contient l'un de mes groupes".
    """

    def test_user_sees_own_entry(self):
        """Vérifie qu'un utilisateur voit ses propres entrées."""
        # --- Act ---
        entries = self.env['password.entry'].with_user(
            self.user_employee
        ).search([('id', '=', self.entry_alice_main.id)])
        # --- Assert ---
        self.assertEqual(len(entries), 1)

    def test_user_does_not_see_other_user_private_entry(self):
        """Vérifie qu'un utilisateur ne voit pas les entrées privées d'un autre."""
        # --- Act ---
        entries = self.env['password.entry'].with_user(
            self.user_employee
        ).search([('id', '=', self.entry_bob_main.id)])
        # --- Assert ---
        self.assertEqual(
            len(entries), 0,
            "user_employee ne doit pas voir l'entrée privée de user_manager."
        )

    def test_user_sees_entry_shared_with_own_group(self):
        """Vérifie qu'un utilisateur voit une entrée partagée avec son groupe."""
        # --- Arrange : partager l'entrée de Bob avec le groupe Utilisateur ---
        entry_shared = self.env['password.entry'].with_user(self.user_manager).create({
            'partner_id': self.partner_bob.id,
            'description': 'Entrée partagée avec groupe user',
            'password': 'sharedpass',
            'shared_group_ids': [(4, self.group_user.id)],
        })
        # --- Act ---
        entries = self.env['password.entry'].with_user(
            self.user_employee
        ).search([('id', '=', entry_shared.id)])
        # --- Assert ---
        self.assertEqual(
            len(entries), 1,
            "user_employee doit voir l'entrée partagée avec son groupe."
        )

    def test_user_does_not_see_entry_shared_with_other_group(self):
        """Vérifie qu'un utilisateur ne voit pas une entrée partagée avec un groupe dont il ne fait pas partie."""
        # --- Arrange : créer un groupe tiers ---
        group_other = self.env['res.groups'].create({'name': 'Groupe Tiers Test'})
        entry_other_group = self.env['password.entry'].with_user(self.user_manager).create({
            'partner_id': self.partner_bob.id,
            'description': 'Entrée partagée groupe tiers',
            'password': 'othergroup',
            'shared_group_ids': [(4, group_other.id)],
        })
        # --- Act ---
        entries = self.env['password.entry'].with_user(
            self.user_employee
        ).search([('id', '=', entry_other_group.id)])
        # --- Assert ---
        self.assertEqual(
            len(entries), 0,
            "user_employee ne doit pas voir une entrée partagée avec un groupe dont il ne fait pas partie."
        )


@tagged('post_install', '-at_install')
class TestRecordRuleManager(PasswordManagerTestCommon):
    """
    Tests de la record rule manager : accès complet à toutes les entrées.
    """

    def test_manager_sees_entry_not_shared_with_anyone(self):
        """Vérifie qu'un manager voit les entrées totalement privées d'autres utilisateurs."""
        # --- Arrange : entrée privée d'user_employee, sans partage ---
        entry_private = self.env['password.entry'].with_user(self.user_employee).create({
            'partner_id': self.partner_alice.id,
            'description': 'Entrée strictement privée',
            'password': 'strictprivate',
        })
        # Vérifier que user_manager peut la voir malgré l'absence de partage
        # --- Act ---
        entries = self.env['password.entry'].with_user(
            self.user_manager
        ).search([('id', '=', entry_private.id)])
        # --- Assert ---
        self.assertEqual(
            len(entries), 1,
            "Le manager doit voir toutes les entrées, y compris les strictement privées."
        )

    def test_manager_count_exceeds_own_entries(self):
        """Vérifie que le manager voit plus d'entrées que celles qu'il a créées lui-même."""
        # --- Act ---
        all_entries = self.env['password.entry'].with_user(self.user_manager).search([])
        own_entries = self.env['password.entry'].with_user(self.user_manager).search([
            ('create_uid', '=', self.user_manager.id)
        ])
        # --- Assert ---
        self.assertGreater(
            len(all_entries), len(own_entries),
            "Le manager doit voir les entrées des autres utilisateurs."
        )
