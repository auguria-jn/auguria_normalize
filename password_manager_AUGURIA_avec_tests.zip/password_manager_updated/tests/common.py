# -*- coding: utf-8 -*-
# =============================================================================
# Module      : password_manager
# Fichier     : tests/common.py
# Description : Classe de base et données de test partagées entre toutes les
#               suites de tests du module password_manager.
# Auteur      : AUDURIA by ANOR
# Création    : 2026-03-04
# Mise à jour : 2026-03-04
# =============================================================================

from odoo.tests.common import TransactionCase, tagged


@tagged('post_install', '-at_install')
class PasswordManagerTestCommon(TransactionCase):
    """
    Classe de base pour les tests du module password_manager.
    Centralise la création des utilisateurs et des données de test réutilisables.

    Données créées dans setUpClass :
    - user_employee    : utilisateur du groupe group_password_user
    - user_manager     : utilisateur du groupe group_password_manager
    - partner_alice    : contact de test principal
    - partner_bob      : contact de test secondaire
    - entry_alice_main : entrée de mot de passe appartenant à user_employee
    """

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        # =====================================================================
        # Groupes de sécurité
        # =====================================================================
        cls.group_user = cls.env.ref('password_manager.group_password_user')
        cls.group_manager = cls.env.ref('password_manager.group_password_manager')

        # =====================================================================
        # Utilisateurs de test
        # =====================================================================
        cls.user_employee = cls.env['res.users'].with_context(
            no_reset_password=True
        ).create({
            'name': 'Alice Test',
            'login': 'test_pw_user',
            'email': 'alice@test.example.com',
            'groups_id': [(6, 0, [
                cls.env.ref('base.group_user').id,
                cls.group_user.id,
            ])],
        })

        cls.user_manager = cls.env['res.users'].with_context(
            no_reset_password=True
        ).create({
            'name': 'Bob Manager',
            'login': 'test_pw_manager',
            'email': 'bob@test.example.com',
            'groups_id': [(6, 0, [
                cls.env.ref('base.group_user').id,
                cls.group_manager.id,
            ])],
        })

        # Troisième utilisateur : ni user, ni manager (utilisateur interne basique)
        cls.user_other = cls.env['res.users'].with_context(
            no_reset_password=True
        ).create({
            'name': 'Charlie Autre',
            'login': 'test_pw_other',
            'email': 'charlie@test.example.com',
            'groups_id': [(6, 0, [
                cls.env.ref('base.group_user').id,
            ])],
        })

        # =====================================================================
        # Contacts de test
        # =====================================================================
        cls.partner_alice = cls.env['res.partner'].create({
            'name': 'Contact Test Alice',
            'email': 'contact.alice@test.example.com',
        })

        cls.partner_bob = cls.env['res.partner'].create({
            'name': 'Contact Test Bob',
            'email': 'contact.bob@test.example.com',
        })

        # =====================================================================
        # Entrées de mot de passe de test
        # =====================================================================
        # Entrée appartenant à user_employee (créée avec son uid)
        cls.entry_alice_main = cls.env['password.entry'].with_user(
            cls.user_employee
        ).create({
            'partner_id': cls.partner_alice.id,
            'description': 'Compte Gmail Alice',
            'login': 'alice@gmail.com',
            'url': 'https://mail.google.com',
            'password': 'S3cr3t!Alice',
        })

        # Entrée appartenant à user_manager
        cls.entry_bob_main = cls.env['password.entry'].with_user(
            cls.user_manager
        ).create({
            'partner_id': cls.partner_bob.id,
            'description': 'Compte GitHub Bob',
            'login': 'bob_dev',
            'url': 'https://github.com',
            'password': 'B0bSecure#2026',
        })
