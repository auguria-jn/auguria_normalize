# -*- coding: utf-8 -*-
# =============================================================================
# Module      : password_manager
# Fichier     : tests/test_business_logic.py
# Description : Tests de la logique métier spécifique au module password_manager.
#               Couvre : get_cipher() (sources de clé), chiffrement/déchiffrement,
#               robustesse face aux données corrompues, display_name, action_view_passwords,
#               génération de clé fallback, compatibilité multi-entrées.
# Auteur      : AUDURIA by ANOR
# Création    : 2026-03-04
# Mise à jour : 2026-03-04
# =============================================================================

from unittest.mock import patch
from odoo.tests.common import tagged
from .common import PasswordManagerTestCommon


@tagged('post_install', '-at_install')
class TestEncryptionRoundtrip(PasswordManagerTestCommon):
    """
    Tests de robustesse du chiffrement/déchiffrement.
    Couvre : mots de passe avec caractères spéciaux, unicode, très longs, vides.
    """

    def test_password_with_special_characters(self):
        """Vérifie le chiffrement/déchiffrement d'un mot de passe avec caractères spéciaux."""
        # --- Arrange ---
        special_pwd = '!@#$%^&*()_+-=[]{}|;:\'",./<>?`~\\'
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Spéciaux',
            'password': special_pwd,
        })
        # --- Assert ---
        self.assertEqual(entry.password, special_pwd)

    def test_password_with_unicode_characters(self):
        """Vérifie le chiffrement/déchiffrement d'un mot de passe avec caractères unicode."""
        # --- Arrange ---
        unicode_pwd = 'Ünïcödé_Pàssw0rd_中文_العربية'
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Unicode',
            'password': unicode_pwd,
        })
        # --- Assert ---
        self.assertEqual(entry.password, unicode_pwd)

    def test_password_very_long(self):
        """Vérifie le chiffrement d'un mot de passe très long (512 caractères)."""
        # --- Arrange ---
        long_pwd = 'A1b2C3d4!' * 64  # 512 chars
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Long password',
            'password': long_pwd,
        })
        # --- Assert ---
        self.assertEqual(entry.password, long_pwd)

    def test_password_single_character(self):
        """Vérifie le chiffrement d'un mot de passe d'un seul caractère."""
        # --- Arrange / Act ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Un caractère',
            'password': 'X',
        })
        # --- Assert ---
        self.assertEqual(entry.password, 'X')

    def test_multiple_entries_independent_encryption(self):
        """Vérifie que le chiffrement de deux entrées est indépendant."""
        # --- Arrange ---
        entry1 = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Indép. 1',
            'password': 'pass_one',
        })
        entry2 = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Indép. 2',
            'password': 'pass_two',
        })
        # --- Assert ---
        self.assertEqual(entry1.password, 'pass_one')
        self.assertEqual(entry2.password, 'pass_two')
        self.assertNotEqual(entry1.encrypted_password, entry2.encrypted_password)


@tagged('post_install', '-at_install')
class TestEncryptionKeyFallback(PasswordManagerTestCommon):
    """
    Tests du mécanisme de chargement de la clé de chiffrement (get_cipher).
    Couvre : clé depuis ir.config_parameter, génération d'une nouvelle clé si absente.
    """

    def test_encryption_key_is_stored_in_config_param_when_generated(self):
        """Vérifie qu'une nouvelle clé est sauvegardée dans ir.config_parameter si elle n'existait pas."""
        # --- Arrange : supprimer la clé existante ---
        IrConfig = self.env['ir.config_parameter'].sudo()
        IrConfig.set_param('password_manager.encryption_key', False)

        # --- Act : créer une entrée pour forcer l'appel de get_cipher ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Génération clé',
            'password': 'KeyGenTest',
        })

        # --- Assert : la clé doit maintenant être présente ---
        key = IrConfig.get_param('password_manager.encryption_key')
        self.assertTrue(key, "Une nouvelle clé doit être générée et stockée dans ir.config_parameter.")
        # Vérifier que le déchiffrement fonctionne avec cette clé
        self.assertEqual(entry.password, 'KeyGenTest')

    def test_key_from_config_param_is_reused(self):
        """Vérifie que la même clé est réutilisée entre deux appels successifs à get_cipher."""
        # --- Arrange ---
        entry1 = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Réutilisation clé 1',
            'password': 'same_key_test_1',
        })
        entry2 = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Réutilisation clé 2',
            'password': 'same_key_test_2',
        })
        # --- Assert : les deux entrées doivent être lisibles (même clé) ---
        self.assertEqual(entry1.password, 'same_key_test_1')
        self.assertEqual(entry2.password, 'same_key_test_2')

    def test_key_from_environment_variable_is_used(self):
        """Vérifie que la clé est chargée depuis la variable d'environnement si définie."""
        from cryptography.fernet import Fernet
        import os

        # --- Arrange : générer une clé valide et la poser en variable d'env ---
        test_key = Fernet.generate_key().decode()
        with patch.dict(os.environ, {'ODOO_PASSWORD_ENCRYPTION_KEY': test_key}):
            # --- Act ---
            entry = self.env['password.entry'].create({
                'partner_id': self.partner_alice.id,
                'description': 'Clé env var',
                'password': 'EnvVarPassword',
            })
            # --- Assert : le déchiffrement doit fonctionner avec la clé d'environnement ---
            self.assertEqual(entry.password, 'EnvVarPassword')


@tagged('post_install', '-at_install')
class TestCorruptedPassword(PasswordManagerTestCommon):
    """
    Tests de robustesse face à des données chiffrées corrompues.
    Couvre : comportement de _compute_password quand le déchiffrement échoue.
    """

    def test_corrupted_encrypted_password_returns_empty(self):
        """Vérifie que password retourne '' si encrypted_password est corrompu (pas d'exception levée)."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Données corrompues',
        })
        # Injecter une valeur corrompue directement en base (bypass write)
        self.env.cr.execute(
            "UPDATE password_entry SET encrypted_password = %s WHERE id = %s",
            ('DONNEES_CORROMPUES_INVALIDES', entry.id)
        )
        entry.invalidate_recordset()

        # --- Act / Assert : doit retourner '' sans lever d'exception ---
        try:
            pwd = entry.password
            self.assertEqual(pwd, '', "Un mot de passe corrompu doit retourner une chaîne vide.")
        except Exception as e:
            self.fail(
                "_compute_password ne doit pas lever d'exception sur des données "
                "corrompues, mais a levé : %s" % e
            )


@tagged('post_install', '-at_install')
class TestDisplayName(PasswordManagerTestCommon):
    """
    Tests de la méthode _compute_display_name.
    Couvre : format avec login, sans login.
    """

    def test_display_name_includes_partner_and_description(self):
        """Vérifie que le display_name contient le nom du contact et la description."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Gmail Pro',
        })
        # --- Assert ---
        self.assertIn(self.partner_alice.name, entry.display_name)
        self.assertIn('Gmail Pro', entry.display_name)

    def test_display_name_includes_login_when_present(self):
        """Vérifie que le display_name inclut le login entre parenthèses quand il est renseigné."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Service avec login',
            'login': 'alice_login',
        })
        # --- Assert ---
        self.assertIn('alice_login', entry.display_name)

    def test_display_name_without_login_has_no_parentheses(self):
        """Vérifie que le display_name sans login ne contient pas de parenthèses de login."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Service sans login',
        })
        # --- Assert : la description est bien dans le display_name ---
        self.assertIn('Service sans login', entry.display_name)


@tagged('post_install', '-at_install')
class TestActionViewPasswords(PasswordManagerTestCommon):
    """
    Tests de la méthode action_view_passwords de res.partner.
    Couvre : structure de l'action, domaine, contexte.
    """

    def test_action_returns_correct_type(self):
        """Vérifie que l'action retournée est de type ir.actions.act_window."""
        # --- Act ---
        action = self.partner_alice.action_view_passwords()
        # --- Assert ---
        self.assertEqual(action.get('type'), 'ir.actions.act_window')

    def test_action_targets_password_entry_model(self):
        """Vérifie que l'action cible le modèle password.entry."""
        # --- Act ---
        action = self.partner_alice.action_view_passwords()
        # --- Assert ---
        self.assertEqual(action.get('res_model'), 'password.entry')

    def test_action_domain_filters_on_partner(self):
        """Vérifie que le domain de l'action filtre sur l'ID du contact courant."""
        # --- Act ---
        action = self.partner_alice.action_view_passwords()
        domain = action.get('domain', [])
        # --- Assert ---
        self.assertIn(('partner_id', '=', self.partner_alice.id), domain)

    def test_action_context_presets_partner(self):
        """Vérifie que le contexte de l'action préremplit le partner_id."""
        # --- Act ---
        action = self.partner_alice.action_view_passwords()
        context = action.get('context', {})
        # --- Assert ---
        self.assertEqual(context.get('default_partner_id'), self.partner_alice.id)

    def test_action_view_mode_includes_list_and_form(self):
        """Vérifie que l'action propose les modes liste et formulaire."""
        # --- Act ---
        action = self.partner_alice.action_view_passwords()
        view_mode = action.get('view_mode', '')
        # --- Assert ---
        self.assertIn('list', view_mode)
        self.assertIn('form', view_mode)
