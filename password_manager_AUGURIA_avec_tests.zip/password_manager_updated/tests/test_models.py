# -*- coding: utf-8 -*-
# =============================================================================
# Module      : password_manager
# Fichier     : tests/test_models.py
# Description : Tests unitaires des modèles password.entry et res.partner.
#               Couvre : CRUD, champs compute/inverse, contraintes SQL,
#               surcharges create/write/unlink/copy, _name_search.
# Auteur      : AUDURIA by ANOR
# Création    : 2026-03-04
# Mise à jour : 2026-03-04
# =============================================================================

from odoo.exceptions import ValidationError
from odoo.tests.common import tagged
from .common import PasswordManagerTestCommon


@tagged('post_install', '-at_install')
class TestPasswordEntryCreate(PasswordManagerTestCommon):
    """
    Tests du modèle password.entry — création et valeurs par défaut.
    Couvre : create(), champs obligatoires, valeurs par défaut, chiffrement initial.
    """

    def test_create_with_required_fields(self):
        """Vérifie que la création avec les champs obligatoires réussit."""
        # --- Arrange / Act ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Nouveau service',
        })
        # --- Assert ---
        self.assertTrue(entry.exists())
        self.assertEqual(entry.partner_id, self.partner_alice)
        self.assertEqual(entry.description, 'Nouveau service')

    def test_create_default_active_is_true(self):
        """Vérifie que le champ active vaut True par défaut."""
        # --- Arrange / Act ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Service actif',
        })
        # --- Assert ---
        self.assertTrue(entry.active)

    def test_create_with_password_encrypts_it(self):
        """Vérifie que la création avec un mot de passe chiffre immédiatement celui-ci."""
        # --- Arrange / Act ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Test chiffrement create',
            'password': 'MonMotDePasseSecret',
        })
        # --- Assert : le clair n'est jamais stocké ---
        self.assertFalse(
            entry.encrypted_password == 'MonMotDePasseSecret',
            "Le mot de passe ne doit pas être stocké en clair."
        )
        self.assertTrue(
            entry.encrypted_password,
            "encrypted_password doit être renseigné après création avec password."
        )

    def test_create_without_password_has_no_encrypted(self):
        """Vérifie qu'une entrée sans mot de passe n'a pas de valeur chiffrée."""
        # --- Arrange / Act ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Sans mot de passe',
        })
        # --- Assert ---
        self.assertFalse(entry.encrypted_password)

    def test_create_multiple_entries_same_partner(self):
        """Vérifie la création de plusieurs entrées distinctes pour un même contact."""
        # --- Arrange / Act ---
        entry1 = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Service A',
            'password': 'passA',
        })
        entry2 = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Service B',
            'password': 'passB',
        })
        # --- Assert ---
        self.assertTrue(entry1.exists())
        self.assertTrue(entry2.exists())
        self.assertNotEqual(entry1.encrypted_password, entry2.encrypted_password)


@tagged('post_install', '-at_install')
class TestPasswordEntryWrite(PasswordManagerTestCommon):
    """
    Tests du modèle password.entry — écriture.
    Couvre : write() avec password, effacement du mot de passe, champs non-password.
    """

    def test_write_password_updates_encrypted(self):
        """Vérifie que l'écriture d'un nouveau mot de passe met à jour encrypted_password."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Mise à jour mdp',
            'password': 'AncienMotDePasse',
        })
        old_encrypted = entry.encrypted_password

        # --- Act ---
        entry.write({'password': 'NouveauMotDePasse'})

        # --- Assert ---
        self.assertNotEqual(
            entry.encrypted_password, old_encrypted,
            "encrypted_password doit changer après écriture d'un nouveau password."
        )

    def test_write_empty_password_clears_encrypted(self):
        """Vérifie que l'écriture d'un mot de passe vide supprime encrypted_password."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Effacement mdp',
            'password': 'MotDePasseAEffacer',
        })
        # --- Act ---
        entry.write({'password': ''})
        # --- Assert ---
        self.assertFalse(entry.encrypted_password)

    def test_write_other_field_does_not_affect_encrypted(self):
        """Vérifie que l'écriture d'un champ sans rapport ne modifie pas le mot de passe chiffré."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Test write autre champ',
            'password': 'MotDePasseStable',
        })
        encrypted_before = entry.encrypted_password

        # --- Act ---
        entry.write({'login': 'nouveau_login@test.com'})

        # --- Assert ---
        self.assertEqual(
            entry.encrypted_password, encrypted_before,
            "encrypted_password ne doit pas changer lors de l'écriture d'un autre champ."
        )


@tagged('post_install', '-at_install')
class TestPasswordEntryUnlink(PasswordManagerTestCommon):
    """
    Tests du modèle password.entry — suppression.
    Couvre : unlink() standard, suppression en cascade depuis le partner.
    """

    def test_unlink_deletes_entry(self):
        """Vérifie que la suppression d'une entrée fonctionne correctement."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Entrée à supprimer',
            'password': 'tmppass',
        })
        entry_id = entry.id
        # --- Act ---
        entry.unlink()
        # --- Assert ---
        self.assertFalse(
            self.env['password.entry'].search([('id', '=', entry_id)]).exists()
        )

    def test_unlink_partner_cascades_to_entries(self):
        """Vérifie que la suppression d'un contact supprime ses entrées (ondelete=cascade)."""
        # --- Arrange ---
        partner_temp = self.env['res.partner'].create({'name': 'Partenaire Temporaire'})
        entry = self.env['password.entry'].create({
            'partner_id': partner_temp.id,
            'description': 'Entrée cascade',
            'password': 'cascadepass',
        })
        entry_id = entry.id
        # --- Act ---
        partner_temp.unlink()
        # --- Assert ---
        self.assertFalse(
            self.env['password.entry'].search([('id', '=', entry_id)]).exists(),
            "L'entrée doit être supprimée en cascade avec son contact."
        )


@tagged('post_install', '-at_install')
class TestPasswordEntryCopy(PasswordManagerTestCommon):
    """
    Tests du modèle password.entry — duplication.
    Couvre : copy() avec suffixe de description, conservation du mot de passe chiffré.
    """

    def test_copy_suffixes_description(self):
        """Vérifie que la duplication suffixe la description avec '(copie)'."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Service Original',
            'password': 'origpass',
        })
        # --- Act ---
        entry_copy = entry.copy()
        # --- Assert ---
        self.assertIn('copie', entry_copy.description.lower())

    def test_copy_preserves_encrypted_password(self):
        """Vérifie que la duplication conserve le mot de passe chiffré d'origine."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Original avec mdp',
            'password': 'MotDePasseOriginal',
        })
        # --- Act ---
        entry_copy = entry.copy()
        # --- Assert ---
        self.assertEqual(
            entry.encrypted_password, entry_copy.encrypted_password,
            "Le mot de passe chiffré doit être identique dans la copie."
        )
        # Le mot de passe déchiffré doit également être identique
        self.assertEqual(entry.password, entry_copy.password)


@tagged('post_install', '-at_install')
class TestPasswordEntryComputePassword(PasswordManagerTestCommon):
    """
    Tests du champ compute password (déchiffrement) et de son inverse (chiffrement).
    Couvre : _compute_password, _inverse_password, cohérence aller-retour.
    """

    def test_compute_password_decrypts_correctly(self):
        """Vérifie que le champ password retourne le mot de passe en clair après création."""
        # --- Arrange / Act ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Test déchiffrement',
            'password': 'ClearTextPassword123!',
        })
        # --- Assert ---
        self.assertEqual(
            entry.password, 'ClearTextPassword123!',
            "Le champ password doit retourner le texte en clair."
        )

    def test_compute_password_empty_when_no_encrypted(self):
        """Vérifie que password est vide si encrypted_password est absent."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Sans mdp',
        })
        # --- Assert ---
        self.assertEqual(entry.password, '')

    def test_inverse_password_roundtrip(self):
        """Vérifie la cohérence aller-retour : ce qu'on écrit est bien ce qu'on lit."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Aller-retour chiffrement',
        })
        test_password = 'R0undTrip!2026#Test'
        # --- Act ---
        entry.write({'password': test_password})
        # --- Assert ---
        self.assertEqual(
            entry.password, test_password,
            "Le mot de passe lu doit être identique à celui écrit."
        )

    def test_encrypted_password_differs_from_clear(self):
        """Vérifie que le texte chiffré est différent du texte en clair."""
        # --- Arrange ---
        clear = 'MotDePasseVisible'
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Vérification chiffrement',
            'password': clear,
        })
        # --- Assert ---
        self.assertNotEqual(entry.encrypted_password, clear)
        # Deux chiffrements du même texte doivent produire des valeurs différentes (Fernet IV aléatoire)
        entry2 = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Vérification IV aléatoire',
            'password': clear,
        })
        self.assertNotEqual(
            entry.encrypted_password, entry2.encrypted_password,
            "Fernet doit produire un token différent à chaque chiffrement (IV aléatoire)."
        )


@tagged('post_install', '-at_install')
class TestPasswordEntryComputeSharingSummary(PasswordManagerTestCommon):
    """
    Tests du champ compute sharing_summary.
    Couvre : _compute_sharing_summary, valeur "Privé", affichage des noms de groupes.
    """

    def test_sharing_summary_private_when_no_groups(self):
        """Vérifie que la visibilité est 'Privé' quand aucun groupe n'est sélectionné."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Entrée privée',
        })
        # --- Assert ---
        self.assertEqual(entry.sharing_summary, 'Privé')

    def test_sharing_summary_shows_group_name_when_shared(self):
        """Vérifie que le résumé affiche le nom du groupe quand un partage est configuré."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Entrée partagée',
        })
        # --- Act ---
        entry.write({'shared_group_ids': [(4, self.group_user.id)]})
        # --- Assert ---
        self.assertNotEqual(entry.sharing_summary, 'Privé')
        self.assertTrue(len(entry.sharing_summary) > 0)

    def test_sharing_summary_updates_when_group_removed(self):
        """Vérifie que le résumé revient à 'Privé' quand les groupes sont retirés."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Partage puis retrait',
            'shared_group_ids': [(4, self.group_user.id)],
        })
        # --- Act ---
        entry.write({'shared_group_ids': [(5,)]})
        # --- Assert ---
        self.assertEqual(entry.sharing_summary, 'Privé')


@tagged('post_install', '-at_install')
class TestPasswordEntrySqlConstraint(PasswordManagerTestCommon):
    """
    Tests de la contrainte SQL UNIQUE(partner_id, description).
    """

    def test_sql_constraint_unique_partner_description(self):
        """Vérifie que deux entrées avec le même contact et la même description sont refusées."""
        from psycopg2 import IntegrityError as PsycopgIntegrityError
        from odoo.exceptions import ValidationError as OdooValidationError

        # --- Arrange ---
        self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Description Unique',
        })
        # --- Act / Assert ---
        with self.assertRaises((PsycopgIntegrityError, OdooValidationError, Exception)):
            with self.cr.savepoint():
                self.env['password.entry'].create({
                    'partner_id': self.partner_alice.id,
                    'description': 'Description Unique',
                })

    def test_same_description_different_partner_is_allowed(self):
        """Vérifie que la même description est autorisée pour deux contacts différents."""
        # --- Arrange / Act ---
        entry1 = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Description Commune',
        })
        entry2 = self.env['password.entry'].create({
            'partner_id': self.partner_bob.id,
            'description': 'Description Commune',
        })
        # --- Assert ---
        self.assertTrue(entry1.exists())
        self.assertTrue(entry2.exists())


@tagged('post_install', '-at_install')
class TestPasswordEntryNameSearch(PasswordManagerTestCommon):
    """
    Tests de la recherche étendue _name_search.
    Couvre : recherche par description, login, URL et nom de contact.
    """

    def test_name_search_by_description(self):
        """Vérifie la recherche par description."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'ServiceRecherche',
            'login': 'user_recherche',
        })
        # --- Act ---
        results = self.env['password.entry']._name_search('ServiceRecherche')
        found_ids = list(results)
        # --- Assert ---
        self.assertIn(entry.id, found_ids)

    def test_name_search_by_login(self):
        """Vérifie la recherche par identifiant login."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Login Unique Search',
            'login': 'login_unique_xyz',
        })
        # --- Act ---
        results = self.env['password.entry']._name_search('login_unique_xyz')
        found_ids = list(results)
        # --- Assert ---
        self.assertIn(entry.id, found_ids)

    def test_name_search_empty_returns_all(self):
        """Vérifie que la recherche vide retourne des enregistrements."""
        # --- Act ---
        results = self.env['password.entry']._name_search('')
        # --- Assert ---
        self.assertGreater(len(list(results)), 0)


@tagged('post_install', '-at_install')
class TestResPartnerExtension(PasswordManagerTestCommon):
    """
    Tests de l'extension res.partner.
    Couvre : password_count (compute), action_view_passwords.
    """

    def test_password_count_increments_on_create(self):
        """Vérifie que password_count augmente quand une entrée est créée pour un contact."""
        # --- Arrange ---
        count_before = self.partner_alice.password_count
        # --- Act ---
        self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Pour le compteur',
            'password': 'countpass',
        })
        self.partner_alice.invalidate_recordset()
        # --- Assert ---
        self.assertEqual(self.partner_alice.password_count, count_before + 1)

    def test_password_count_decrements_on_unlink(self):
        """Vérifie que password_count diminue quand une entrée est supprimée."""
        # --- Arrange ---
        entry = self.env['password.entry'].create({
            'partner_id': self.partner_alice.id,
            'description': 'Entrée pour décompte',
        })
        self.partner_alice.invalidate_recordset()
        count_with = self.partner_alice.password_count
        # --- Act ---
        entry.unlink()
        self.partner_alice.invalidate_recordset()
        # --- Assert ---
        self.assertEqual(self.partner_alice.password_count, count_with - 1)

    def test_action_view_passwords_returns_act_window(self):
        """Vérifie que action_view_passwords retourne une action ir.actions.act_window."""
        # --- Act ---
        action = self.partner_alice.action_view_passwords()
        # --- Assert ---
        self.assertEqual(action.get('type'), 'ir.actions.act_window')
        self.assertEqual(action.get('res_model'), 'password.entry')

    def test_action_view_passwords_filters_on_partner(self):
        """Vérifie que l'action filtre les entrées sur le contact courant."""
        # --- Act ---
        action = self.partner_alice.action_view_passwords()
        # --- Assert ---
        domain = action.get('domain', [])
        # Le domain doit contenir un filtre sur partner_id
        domain_str = str(domain)
        self.assertIn('partner_id', domain_str)
        self.assertIn(str(self.partner_alice.id), domain_str)
