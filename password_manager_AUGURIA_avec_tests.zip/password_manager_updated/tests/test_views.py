# -*- coding: utf-8 -*-
# =============================================================================
# Module      : password_manager
# Fichier     : tests/test_views.py
# Description : Tests de cohérence des vues XML du module password_manager.
#               Vérifie que chaque vue se charge sans erreur et que les actions
#               window pointent vers des modèles existants.
# Auteur      : AUDURIA by ANOR
# Création    : 2026-03-04
# Mise à jour : 2026-03-04
# =============================================================================

from odoo.tests.common import tagged
from .common import PasswordManagerTestCommon


@tagged('post_install', '-at_install')
class TestPasswordEntryViews(PasswordManagerTestCommon):
    """
    Tests de chargement des vues password.entry.
    Couvre : vue liste, vue formulaire, vue recherche.
    """

    def test_list_view_exists_and_loads(self):
        """Vérifie que la vue liste password.entry existe et est valide."""
        # --- Act ---
        view = self.env.ref('password_manager.view_password_entry_list')
        # --- Assert ---
        self.assertTrue(view.exists())
        self.assertEqual(view.model, 'password.entry')
        self.assertEqual(view.type, 'list')

    def test_form_view_exists_and_loads(self):
        """Vérifie que la vue formulaire password.entry existe et est valide."""
        # --- Act ---
        view = self.env.ref('password_manager.view_password_entry_form')
        # --- Assert ---
        self.assertTrue(view.exists())
        self.assertEqual(view.model, 'password.entry')
        self.assertEqual(view.type, 'form')

    def test_search_view_exists_and_loads(self):
        """Vérifie que la vue de recherche password.entry existe et est valide."""
        # --- Act ---
        view = self.env.ref('password_manager.view_password_entry_search')
        # --- Assert ---
        self.assertTrue(view.exists())
        self.assertEqual(view.model, 'password.entry')
        self.assertEqual(view.type, 'search')

    def test_form_view_arch_contains_password_field(self):
        """Vérifie que la vue formulaire contient bien le champ password."""
        # --- Act ---
        view = self.env.ref('password_manager.view_password_entry_form')
        # --- Assert ---
        self.assertIn('password', view.arch)

    def test_form_view_arch_contains_shared_group_ids(self):
        """Vérifie que la vue formulaire contient le champ de partage par groupes."""
        # --- Act ---
        view = self.env.ref('password_manager.view_password_entry_form')
        # --- Assert ---
        self.assertIn('shared_group_ids', view.arch)

    def test_list_view_arch_contains_sharing_summary(self):
        """Vérifie que la vue liste contient la colonne de visibilité."""
        # --- Act ---
        view = self.env.ref('password_manager.view_password_entry_list')
        # --- Assert ---
        self.assertIn('sharing_summary', view.arch)

    def test_search_view_has_my_entries_filter(self):
        """Vérifie que la vue de recherche contient le filtre 'Mes mots de passe'."""
        # --- Act ---
        view = self.env.ref('password_manager.view_password_entry_search')
        # --- Assert ---
        self.assertIn('my_entries', view.arch)


@tagged('post_install', '-at_install')
class TestResPartnerInheritedView(PasswordManagerTestCommon):
    """
    Tests de la vue héritée res.partner.
    Couvre : vue formulaire contact avec stat button et onglet Sécurité.
    """

    def test_partner_form_inherited_view_exists(self):
        """Vérifie que la vue héritée du formulaire contact existe."""
        # --- Act ---
        view = self.env.ref('password_manager.view_partner_form_password')
        # --- Assert ---
        self.assertTrue(view.exists())
        self.assertEqual(view.model, 'res.partner')

    def test_partner_form_inherited_view_references_base(self):
        """Vérifie que la vue héritée référence bien base.view_partner_form."""
        # --- Act ---
        view = self.env.ref('password_manager.view_partner_form_password')
        # --- Assert ---
        self.assertTrue(view.inherit_id.exists())
        self.assertEqual(view.inherit_id.xml_id, 'base.view_partner_form')

    def test_partner_form_arch_contains_password_entry_ids(self):
        """Vérifie que la vue contact contient le champ password_entry_ids."""
        # --- Act ---
        view = self.env.ref('password_manager.view_partner_form_password')
        # --- Assert ---
        self.assertIn('password_entry_ids', view.arch)

    def test_partner_form_arch_contains_security_page(self):
        """Vérifie que la vue contact contient l'onglet Sécurité."""
        # --- Act ---
        view = self.env.ref('password_manager.view_partner_form_password')
        # --- Assert ---
        self.assertIn('security', view.arch)


@tagged('post_install', '-at_install')
class TestActions(PasswordManagerTestCommon):
    """
    Tests de cohérence des actions window.
    Couvre : action principale, action "Mes mots de passe", modèles valides.
    """

    def test_action_password_entry_exists(self):
        """Vérifie que l'action principale 'Mots de passe' existe."""
        # --- Act ---
        action = self.env.ref('password_manager.action_password_entry')
        # --- Assert ---
        self.assertTrue(action.exists())
        self.assertEqual(action.res_model, 'password.entry')

    def test_action_password_entry_my_exists(self):
        """Vérifie que l'action dédiée 'Mes mots de passe' existe."""
        # --- Act ---
        action = self.env.ref('password_manager.action_password_entry_my')
        # --- Assert ---
        self.assertTrue(action.exists())
        self.assertEqual(action.res_model, 'password.entry')

    def test_action_password_entry_my_has_domain(self):
        """Vérifie que l'action 'Mes mots de passe' a un domain défini."""
        # --- Act ---
        action = self.env.ref('password_manager.action_password_entry_my')
        # --- Assert ---
        self.assertTrue(action.domain, "L'action 'Mes mots de passe' doit avoir un domain.")

    def test_all_module_actions_point_to_valid_models(self):
        """Vérifie que toutes les actions window du module pointent vers des modèles existants."""
        # --- Act ---
        actions = self.env['ir.actions.act_window'].search([
            ('res_model', 'in', ['password.entry', 'res.partner']),
        ])
        # --- Assert ---
        for action in actions:
            self.assertIn(
                action.res_model,
                self.env,
                "L'action '%s' pointe vers un modèle inexistant : %s" % (
                    action.name, action.res_model
                )
            )

    def test_menus_reference_valid_actions(self):
        """Vérifie que les menus du module référencent des actions existantes."""
        # --- Act ---
        menu_root = self.env.ref('password_manager.menu_password_manager_root')
        menu_all = self.env.ref('password_manager.menu_password_entries')
        menu_my = self.env.ref('password_manager.menu_password_my_entries')
        # --- Assert ---
        self.assertTrue(menu_root.exists())
        self.assertTrue(menu_all.exists())
        self.assertTrue(menu_my.exists())
        # Les sous-menus doivent avoir une action associée
        self.assertTrue(
            menu_all.action.exists(),
            "Le menu 'Tous les mots de passe' doit référencer une action valide."
        )
        self.assertTrue(
            menu_my.action.exists(),
            "Le menu 'Mes mots de passe' doit référencer une action valide."
        )


@tagged('post_install', '-at_install')
class TestSecurityGroups(PasswordManagerTestCommon):
    """
    Tests de cohérence des groupes et record rules de sécurité.
    """

    def test_group_password_user_exists(self):
        """Vérifie que le groupe group_password_user est défini."""
        # --- Act ---
        group = self.env.ref('password_manager.group_password_user')
        # --- Assert ---
        self.assertTrue(group.exists())

    def test_group_password_manager_exists(self):
        """Vérifie que le groupe group_password_manager est défini."""
        # --- Act ---
        group = self.env.ref('password_manager.group_password_manager')
        # --- Assert ---
        self.assertTrue(group.exists())

    def test_group_manager_implies_group_user(self):
        """Vérifie que le groupe Manager implique le groupe Utilisateur."""
        # --- Act ---
        group_manager = self.env.ref('password_manager.group_password_manager')
        group_user = self.env.ref('password_manager.group_password_user')
        # --- Assert ---
        self.assertIn(
            group_user,
            group_manager.implied_ids,
            "group_password_manager doit impliquer group_password_user."
        )

    def test_record_rules_exist(self):
        """Vérifie que les deux record rules sont définies."""
        # --- Act ---
        rule_user = self.env.ref('password_manager.password_entry_user_rule')
        rule_manager = self.env.ref('password_manager.password_entry_manager_rule')
        # --- Assert ---
        self.assertTrue(rule_user.exists())
        self.assertTrue(rule_manager.exists())

    def test_record_rule_user_applies_to_user_group(self):
        """Vérifie que la record rule utilisateur est attachée au bon groupe."""
        # --- Act ---
        rule_user = self.env.ref('password_manager.password_entry_user_rule')
        group_user = self.env.ref('password_manager.group_password_user')
        # --- Assert ---
        self.assertIn(group_user, rule_user.groups)

    def test_record_rule_manager_applies_to_manager_group(self):
        """Vérifie que la record rule manager est attachée au bon groupe."""
        # --- Act ---
        rule_manager = self.env.ref('password_manager.password_entry_manager_rule')
        group_manager = self.env.ref('password_manager.group_password_manager')
        # --- Assert ---
        self.assertIn(group_manager, rule_manager.groups)
